package org.example;

import java.awt.*;
import Functionality.Display;

public class Main {
    public static final String path = "src/main/java/Data";

    public static void main(String[] args) {
        Display menu = new Display();
        menu.introScreen();
        menu.mainMenu();
    }
}